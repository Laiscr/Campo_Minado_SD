/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
#define i 4
#define j 4
int posicao_bomba[i][j] = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0} } ;
int x, y, vezes;
char erro[]="xx";
char vetor_string[3];//letra + número + quebra de linha(\0)
int b1, b2, b3, b4, bA, bB, bC, bD;
char retorno_num, retorno_letra, linha, coluna;






/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */
void Teste_Leds();
void Teste_Buzzer();
void Teste_Botao();
void Posicao_da_Bomba();
void Fim_Jogo();
void Jogada_Certa();
char Error_xx(char *ponteiro_erro);
char Coluna_ABCD();
int Linha_1234();
void Coluna_Linha(char *p_linhaEcoluna);
void Coordenadas_iguais();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
	  //Teste_Leds();
	  //Teste_Buzzer();
	  //Teste_Botao();
	  Posicao_da_Bomba();
	  //Fim_Jogo();
	  //Jogada_Certa();
	  //Error_xx(erro);
	  //Coluna_ABCD();
	  //Linha_1234();
	  Coluna_Linha(&vetor_string[0]);
	  Coordenadas_iguais();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA2 PA3 PA4 PA5
                           PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB10 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB11 PB3 PB4 PB5
                           PB6 PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void Teste_Leds()
{
	//Led1-B0 em B4
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);//Liga
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);//Desliga
	//
	HAL_Delay(200);
	//
	//Led2-B1 em B5
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 1);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 0);
	//
	HAL_Delay(200);
	//
	//Led3-B2 em B6
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 1);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);
	//
	HAL_Delay(200);
	//
	//Led4-B3 em B7
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 1);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
	//
    HAL_Delay(200);
    //
    //Led5-B4 em B8
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
    HAL_Delay(200);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    //
    HAL_Delay(200);
    //
    //Led6-B5 em B9
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
    HAL_Delay(200);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    //
    HAL_Delay(200);
    //
    //Led7-B6 em B3
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
    HAL_Delay(200);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);
    //
    HAL_Delay(200);
    //
    //Led8-B7 em C14
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 1);
    HAL_Delay(200);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 0);
    //
    HAL_Delay(200);
    //
}
////////////////////////////////////////////////////////////
void Teste_Buzzer()
{
	//Buzzer
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);//Liga
	    HAL_Delay(1000);
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 1);//Desliga
}
////////////////////////////////////////////////////////////
void Teste_Botao()
{
	//SEQUÊNCIA DE Nº: (1,2,3,4) ---PLACA 1

	//Botão SW1 em B10 com Led1-B0 em B4
	b1 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10);
	if(b1==0)
	{
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);
		 HAL_Delay(1000);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);
		 HAL_Delay(500);
	}

	//Botão SW2 em B1 com Led2-B1 em B5
    b2 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
	if(b2==0)
	{
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 1);
		 HAL_Delay(1000);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 0);
		 HAL_Delay(500);
	}

	//Botão SW3 em B0 com Led3-B2 em B6
	b3 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
	if(b3==0)
	{
	     HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 1);
		 HAL_Delay(1000);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);
		 HAL_Delay(500);
	}

	//Botão SW4 em A7 com Led4-B3 em 7
	b4 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7);
	if(b4==0)
	{
		     HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 1);
			 HAL_Delay(1000);
			 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
			 HAL_Delay(500);
	}

	//SEQUÊNCIA DE LETRAS: (A,B,C,D) --- PLACA 2

	//Botão SW1 em A5 com Led5-B4 em B8
	bA = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5);
	if(bA==0)
	{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
			HAL_Delay(500);
	}

	//Botão SW2 em A4 com Led6-B5 em B9
	    bB = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
		if(bB==0)
		{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
			HAL_Delay(500);
		}

		//Botão SW3 em A3 com Led7-B6 em B6 em B3
		bC = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3);
		if(bC==0)
		{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);
			HAL_Delay(500);
		}

		//Botão SW4 em A2 com Led8-B7 em C14
		bD = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		if(bD==0)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 1);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 0);
			HAL_Delay(500);
		}
}
////////////////////////////////////////////////////////////
void Posicao_da_Bomba()

{

    vezes=0; //precisa redefinir o valor da variável quando rodar o programa, pois seu valor se altera, não se tornando mais o que era preciso
	while(vezes<=3)//vai de 0 a 3, ou seja, 4 vezes incluindo o 0
	{
		x = rand() % 4; //restos: 0, 1 , 2, 3 (4 números equivalentes às 4 posições i, j na matriz)
	    y = rand() % 4; //identificará os nº da posições da matriz 4x4;
	    //dentro do loop, ambas as operações x e y, aleatoriamente, serão criadas 4 coordenadas que definirão as posições das 4 bombas

		if(posicao_bomba[x][y]==0)
		{
			posicao_bomba[x][y] = 1; //quando definidos os valores de x e y, logo, a posição na matriz, colocará a bomba (1) na posição de 0
			vezes++;
		}
    }
}
////////////////////////////////////////////////////////////
void Fim_Jogo()

{
     	while (b1==1 || b2==1 || b3==1 || b4==1 || bA==1 || bB==1 || bC==1 || bD==1)
     	{
     		//Botões desligam tudo

     		     //SEQUÊNCIA DE Nº: (1,2,3,4) ---PLACA 1
     		     	//Botão SW1 em B10 com Led1-B0
     		     	 b1 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10); //Se a leitura não for feita dentro do while que verifica
     		     	                                            //constantemente o estado dos pinos, o compilador só lerá o estado das variáveis, não mais dos pinos.
     		     	//Botão SW2 em B1 com Led2-B1
     		     	 b2 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
     		     	//Botão SW3 em B0 com Led3-B2
     		     	 b3 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
     		     	//Botão SW4 em A7 com Led4-B3
     		     	 b4 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7);

     		     //SEQUÊNCIA DE LETRAS: (A,B,C,D) --- PLACA 2
     		     	//Botão SW1 em A5 com Led5-B4
     		     	 bA = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5);
     		    	//Botão SW2 em A4 com Led6-B5
     		         bB = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
     		        //Botão SW3 em A3 com Led7-B6
     		         bC = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3);
     		        //Botão SW4 em A2 com Led8-B7
     		         bD = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);

     		Teste_Leds();

     		//Buzzer
     		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);//Liga
     		HAL_Delay(3000);
     		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 1);//Desliga
     		HAL_Delay(3000);
     	}

     	HAL_Delay(1000);
}
////////////////////////////////////////////////////////////
void Jogada_Certa()
{
	    //Liga
	    //Led1-B0 em B4
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);
		//Led2-B1 em B5
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 1);
		//Led3-B2 em B6
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 1);
		//Led4-B3 em B7
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 1);
		//Led5-B4 em B8
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
		//Led6-B5 em B9
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
		//Led7-B6 em B3
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
		//Led8-B7 em C14
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 1);
		HAL_Delay(1000);

		//Desliga
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 0);

		HAL_Delay(500);


}
////////////////////////////////////////////////////////////
char Error_xx(char *ponteiro_erro)
{
	ponteiro_erro=erro;
}
////////////////////////////////////////////////////////////
char Coluna_ABCD()
{
	bA = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5);
	bB = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	bC = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3);
	bD = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);

	if (bA == 0) { return 'A'; }
 	else if (bB == 0) { return 'B'; }
 	else if (bC == 0) { return 'C'; }
 	else if (bD == 0) { return 'D'; }
 	//else { return 'x'; }

}
////////////////////////////////////////////////////////////
int Linha_1234()
{
	b1 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10);
	b2 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
	b3 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
	b4 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7);

	if (b1 == 0) { return '1'; }
	else if (b2 == 0) { return '2'; }
	else if (b3 == 0) { return '3'; }
	else if (b4 == 0) { return '4'; }
	//else { return 'x'; }
}
////////////////////////////////////////////////////////////
void Coluna_Linha(char *p_linhaEcoluna)
{
	int l = 0;
	retorno_letra=Coluna_ABCD();

	if (retorno_letra == 1)//nenhum botão pressionado
	{
	  Error_xx(erro);
	}

	else
	{
    *p_linhaEcoluna=retorno_letra;//o ponteiro põe o conteúdo do retorno dentro da posição do vetor indicado pelo  seu endereço
	 p_linhaEcoluna++;

	 retorno_num=Linha_1234();
	  if (retorno_num == 1)//nenhum botão pressionado
	  {
	   Error_xx(erro);
	  }
	  else
	  {
	  *p_linhaEcoluna=retorno_num;
	  }
	}
}
////////////////////////////////////////////////////////////
/*void Coordenadas_iguais()
{
	//coluna da matriz
	if(y == 'A')
	{
	  coluna = 0;
	}

	else if(y == 'B')
	{
	  coluna = 1;
	}

	else if(y == 'C')
	{
	  coluna = 2;
	}

	else if(y == 'D')
	{
	  coluna = 3;
	}


	//linha da matriz
	if(x == '1')
	{
	  linha = 0;
	}

	else if(x == '2')
	{
	  linha = 1;
	}

	else if(x == '3')
	{
	  linha = 2;
	}

	else if(x == '4')
	{
	  linha = 3;
	}

	//posição da bomba
	if(posicao_bomba[linha][coluna] == 1)
	{
	  return 1;
	}

	else
	{
	  return 0;
	}

}*
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
